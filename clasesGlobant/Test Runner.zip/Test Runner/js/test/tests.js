/* var expect = chai.expect;

describe('Test función sumatoria', function () {
    it('Con todos los elementos positivos', function () {
        var entrada = [1, 2, 3];
        var salida = sumatoria(entrada);

        expect(salida).to.equal(6);
    });
}); */

var expect = chai.expect;



describe('Test función ingresar', function (){
    it('Con números mayor a cero', function (){
        var ale = new Cuenta('Ale', 500);
        
        expect(salida).to.be('true');
    });
});