window.onload = function () {
    init();
}

function init() {
    
var nombre = document.getElementById('formNombre');
var apellido = document.getElementById('formApellido');
var email = document.getElementById('formEmail');
var contraseña = document.getElementById('formContraseña');


function campoObligatorio(event) {
    var elemento = event.target;
    
    if (elemento.value.length == 0){
        elemento.nextElementSibling.hidden = false;     
    }
    else{
        elemento.nextElementSibling.hidden = true;
    }
}

nombre.addEventListener('blur', campoObligatorio, false);
email.addEventListener('blur', campoObligatorio, false);
contraseña.addEventListener('blur', campoObligatorio, false);

}


